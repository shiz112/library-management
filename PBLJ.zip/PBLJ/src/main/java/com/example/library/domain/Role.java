package com.example.library.domain;

public enum Role {
    LIBRARIAN,
    STUDENT
}


